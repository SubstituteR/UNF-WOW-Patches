#pragma once
#define WIN32_LEAN_AND_MEAN 
#include <windows.h>
#include <string patch/stringpatch.h>
#include <login patch/loginpatch.h>
#include "wowFunctions.h"

login_t WOW::Auth::Login = login_t(nullptr);
msgbox_t WOW::GUI::MsgBox = msgbox_t(nullptr);
processVariable<int> WOW::Config::ToSAccepted = processVariable<int>(nullptr);
processVariable<int> WOW::Config::EULAAccepted = processVariable<int>(nullptr);
processVariable<int> WOW::Auth::LoginStatus = processVariable<int>(nullptr);

loginCallbacks_t WOW::Auth::LoginCallbacks = loginCallbacks_t(nullptr);

void initFunctions()
{
	WOW::Auth::Login = login_t(NULL, 0xD8A30);
	WOW::Auth::LoginCallbacks = loginCallbacks_t(NULL, 0xDAB40);
	WOW::Auth::LoginStatus = processVariable<int>(NULL, 0x6C3DA4);

	WOW::GUI::MsgBox = msgbox_t(NULL, 0x41B530);

	WOW::Config::ToSAccepted = processVariable<int>(NULL, 0x76AF54);
	WOW::Config::EULAAccepted = processVariable<int>(NULL, 0x76AF5C);

	
}

void Init()
{
	initFunctions();
	Patches::Add<stringPatch>();
	Patches::Add<loginPatch>();
}