#pragma once
#include "hookableFunction.h"

HOOKABLE(login_t, void, char*, char*)
HOOKABLE_VA(msgbox_t, int, int, const char*)
HOOKABLE(loginCallbacks_t, void)


namespace WOW
{
	namespace Config
	{
		extern processVariable<int> ToSAccepted;
		extern processVariable<int> EULAAccepted;
	}
	namespace Auth
	{
		extern login_t Login;
		extern processVariable<int> LoginStatus;
		extern loginCallbacks_t LoginCallbacks;
	}
	namespace GUI
	{
		extern msgbox_t MsgBox;
	}
}

